package utilities;

public class TestUtil {

	static int PAGE_LOAD_TIMEOUT=50;
			static int IMPLICIT_WAIT=30;

}
